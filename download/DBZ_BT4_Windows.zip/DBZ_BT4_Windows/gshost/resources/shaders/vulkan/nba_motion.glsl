#version 460 core

// PS2Recomp: motion vectors for DLSS, estimated from the frames themselves (a PS2 game gives the
// GS screen-space vertices only, no per-object motion). Hierarchical block matching on luma:
//   PASS 0  colour (render rect)  -> luma at 1/2 resolution
//   PASS 1  luma 1/2              -> luma 1/4
//   PASS 2  search at 1/4: current vs previous luma, +-RADIUS texels, 5x5 patch SAD
//   PASS 3  refine at 1/2 around 2x the 1/4 vector (+-1 texel), also tries zero
//   PASS 4  1/2 vectors -> render-resolution vectors in pixels (DLSS input, MVLowRes)
//   PASS 5  match cost of the 1/2 vectors -> "bias current colour" mask at render resolution:
//           where no good match was found (fast thin limbs, disocclusion) DLSS trusts the
//           current frame instead of its history, so those areas stay sharp
// Vectors point from a pixel of the current frame to where it was in the previous one.
// The including code prepends "#define PASS n".

layout(push_constant) uniform const_buffer
{
    ivec4 c0; // PASS 0: src rect xy, dst size; others: dst size in c0.zw
    vec4 c1;  // PASS 4: x = vector sign/scale; PASS 5: x, y = cost per texel for mask 0 and 1
    ivec4 c2;
    ivec4 c3;
};

layout(set=0, binding=0) uniform sampler2D src0;
layout(set=0, binding=1) uniform sampler2D src1;
layout(set=0, binding=2) uniform sampler2D src2;
#if PASS == 0 || PASS == 1 || PASS == 5
layout(set=0, binding=3, r32f) uniform writeonly image2D dst;
#else
layout(set=0, binding=3, rgba16f) uniform writeonly image2D dst;
#endif

const int RADIUS = 4;

float Luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

float Cur(ivec2 p) { return texelFetch(src0, clamp(p, ivec2(0), textureSize(src0, 0) - 1), 0).r; }
float Prev(ivec2 p) { return texelFetch(src1, clamp(p, ivec2(0), textureSize(src1, 0) - 1), 0).r; }

float Sad(ivec2 p, ivec2 d)
{
    float s = 0.0;
    for (int y = -2; y <= 2; y++)
        for (int x = -2; x <= 2; x++)
            s += abs(Cur(p + ivec2(x, y)) - Prev(p + ivec2(x, y) + d));
    return s;
}

layout(local_size_x=8, local_size_y=8) in;
void main()
{
    ivec2 p = ivec2(gl_GlobalInvocationID.xy);
    if (any(greaterThanEqual(p, c0.zw)))
        return;
#if PASS == 0
    ivec2 s = c0.xy + p * 2;
    float l = Luma(texelFetch(src0, s, 0).rgb) + Luma(texelFetch(src0, s + ivec2(1, 0), 0).rgb) +
              Luma(texelFetch(src0, s + ivec2(0, 1), 0).rgb) + Luma(texelFetch(src0, s + ivec2(1, 1), 0).rgb);
    imageStore(dst, p, vec4(l * 0.25));
#elif PASS == 1
    ivec2 s = p * 2;
    float l = texelFetch(src0, s, 0).r + texelFetch(src0, s + ivec2(1, 0), 0).r +
              texelFetch(src0, s + ivec2(0, 1), 0).r + texelFetch(src0, s + ivec2(1, 1), 0).r;
    imageStore(dst, p, vec4(l * 0.25));
#elif PASS == 2
    // Small bias towards no motion: flat areas and the HUD stay still.
    ivec2 best = ivec2(0);
    float bestCost = Sad(p, ivec2(0)) * 0.9;
    for (int y = -RADIUS; y <= RADIUS; y++)
        for (int x = -RADIUS; x <= RADIUS; x++)
        {
            float cost = Sad(p, ivec2(x, y)) + 0.01 * float(abs(x) + abs(y));
            if (cost < bestCost) { bestCost = cost; best = ivec2(x, y); }
        }
    imageStore(dst, p, vec4(vec2(best), bestCost, 0.0));
#elif PASS == 3
    ivec2 init = ivec2(texelFetch(src2, clamp(p / 2, ivec2(0), textureSize(src2, 0) - 1), 0).xy) * 2;
    ivec2 best = ivec2(0);
    float bestCost = Sad(p, ivec2(0)) * 0.9;
    for (int y = -1; y <= 1; y++)
        for (int x = -1; x <= 1; x++)
        {
            ivec2 d = init + ivec2(x, y);
            float cost = Sad(p, d) + 0.01 * float(abs(d.x) + abs(d.y));
            if (cost < bestCost) { bestCost = cost; best = d; }
        }
    // Sub-texel refinement: a parabola through the costs either side of the best match on each
    // axis (an integer vector here is 2 render pixels, far too coarse for slow camera pans).
    vec2 frac = vec2(0.0);
    float cx0 = Sad(p, best - ivec2(1, 0)), cx1 = Sad(p, best + ivec2(1, 0));
    float cy0 = Sad(p, best - ivec2(0, 1)), cy1 = Sad(p, best + ivec2(0, 1));
    float c = Sad(p, best);
    float dx = cx0 - 2.0 * c + cx1, dy = cy0 - 2.0 * c + cy1;
    if (dx > 1e-5) frac.x = clamp(0.5 * (cx0 - cx1) / dx, -0.5, 0.5);
    if (dy > 1e-5) frac.y = clamp(0.5 * (cy0 - cy1) / dy, -0.5, 0.5);
    imageStore(dst, p, vec4(vec2(best) + frac, bestCost, 0.0));
#elif PASS == 5
    // Worst match cost around the pixel (3x3 at 1/2 res) so the mask covers limb edges too.
    ivec2 h = p / 2, mx = textureSize(src0, 0) - 1;
    float cost = 0.0;
    for (int y = -1; y <= 1; y++)
        for (int x = -1; x <= 1; x++)
            cost = max(cost, texelFetch(src0, clamp(h + ivec2(x, y), ivec2(0), mx), 0).z);
    imageStore(dst, p, vec4(smoothstep(c1.x, c1.y, cost / 25.0)));
#else
    // Bilinear between the 1/2-resolution vectors (no blocky steps between neighbours).
    vec2 uv = (vec2(p) + 0.5) / vec2(c0.zw);
    vec2 v = texture(src0, uv).xy * 2.0;
    imageStore(dst, p, vec4(v * c1.x, 0.0, 0.0));
#endif
}
