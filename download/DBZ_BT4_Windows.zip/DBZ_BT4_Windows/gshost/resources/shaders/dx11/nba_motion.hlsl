// PS2Recomp: motion vectors for DLSS estimated from the frames (Direct3D 12 version of
// shaders/vulkan/nba_motion.glsl, same passes and results). PASS is defined by the compiler:
//   0  colour (render rect)  -> luma at 1/2 resolution
//   1  luma 1/2              -> luma 1/4
//   2  search at 1/4: current vs previous luma, +-RADIUS texels, 5x5 patch SAD
//   3  refine at 1/2 around 2x the 1/4 vector (+-1 texel, sub-texel parabola fit)
//   4  1/2 vectors -> render-resolution vectors in pixels (bilinear), pointing to the previous frame
//   5  match cost -> "bias current colour" mask (DLSS trusts the current frame where no match)

cbuffer Constants : register(b0)
{
    int4 c0;   // PASS 0: src rect xy; all: dst size in zw
    float4 c1; // PASS 4: x = vector sign/scale; PASS 5: x, y = cost per texel for mask 0 and 1
    int4 c2;
    int4 c3;
};

Texture2D<float4> src0 : register(t0);
Texture2D<float4> src1 : register(t1);
Texture2D<float4> src2 : register(t2);
#if PASS == 0 || PASS == 1 || PASS == 5
RWTexture2D<float> dst : register(u0);
#else
RWTexture2D<float4> dst : register(u0);
#endif

static const int RADIUS = 4;

int2 Size(Texture2D<float4> t)
{
    uint w, h;
    t.GetDimensions(w, h);
    return int2(w, h);
}

float Luma(float3 c) { return dot(c, float3(0.299, 0.587, 0.114)); }
float Cur(int2 p) { return src0.Load(int3(clamp(p, int2(0, 0), Size(src0) - 1), 0)).r; }
float Prev(int2 p) { return src1.Load(int3(clamp(p, int2(0, 0), Size(src1) - 1), 0)).r; }

float Sad(int2 p, int2 d)
{
    float s = 0.0;
    for (int y = -2; y <= 2; y++)
        for (int x = -2; x <= 2; x++)
            s += abs(Cur(p + int2(x, y)) - Prev(p + int2(x, y) + d));
    return s;
}

[numthreads(8, 8, 1)]
void main(uint3 id : SV_DispatchThreadID)
{
    int2 p = int2(id.xy);
    if (any(p >= c0.zw))
        return;
#if PASS == 0
    int2 s = c0.xy + p * 2;
    float l = Luma(src0.Load(int3(s, 0)).rgb) + Luma(src0.Load(int3(s + int2(1, 0), 0)).rgb) +
              Luma(src0.Load(int3(s + int2(0, 1), 0)).rgb) + Luma(src0.Load(int3(s + int2(1, 1), 0)).rgb);
    dst[p] = l * 0.25;
#elif PASS == 1
    int2 s = p * 2;
    float l = src0.Load(int3(s, 0)).r + src0.Load(int3(s + int2(1, 0), 0)).r +
              src0.Load(int3(s + int2(0, 1), 0)).r + src0.Load(int3(s + int2(1, 1), 0)).r;
    dst[p] = l * 0.25;
#elif PASS == 2
    int2 best = int2(0, 0);
    float bestCost = Sad(p, int2(0, 0)) * 0.9;
    for (int y = -RADIUS; y <= RADIUS; y++)
        for (int x = -RADIUS; x <= RADIUS; x++)
        {
            float cost = Sad(p, int2(x, y)) + 0.01 * float(abs(x) + abs(y));
            if (cost < bestCost) { bestCost = cost; best = int2(x, y); }
        }
    dst[p] = float4(float2(best), bestCost, 0.0);
#elif PASS == 3
    int2 init = int2(src2.Load(int3(clamp(p / 2, int2(0, 0), Size(src2) - 1), 0)).xy) * 2;
    int2 best = int2(0, 0);
    float bestCost = Sad(p, int2(0, 0)) * 0.9;
    for (int y = -1; y <= 1; y++)
        for (int x = -1; x <= 1; x++)
        {
            int2 d = init + int2(x, y);
            float cost = Sad(p, d) + 0.01 * float(abs(d.x) + abs(d.y));
            if (cost < bestCost) { bestCost = cost; best = d; }
        }
    float2 frac = float2(0.0, 0.0);
    float cx0 = Sad(p, best - int2(1, 0)), cx1 = Sad(p, best + int2(1, 0));
    float cy0 = Sad(p, best - int2(0, 1)), cy1 = Sad(p, best + int2(0, 1));
    float c = Sad(p, best);
    float dx = cx0 - 2.0 * c + cx1, dy = cy0 - 2.0 * c + cy1;
    if (dx > 1e-5) frac.x = clamp(0.5 * (cx0 - cx1) / dx, -0.5, 0.5);
    if (dy > 1e-5) frac.y = clamp(0.5 * (cy0 - cy1) / dy, -0.5, 0.5);
    dst[p] = float4(float2(best) + frac, bestCost, 0.0);
#elif PASS == 5
    int2 hp = p / 2, mxx = Size(src0) - 1;
    float cost = 0.0;
    for (int y = -1; y <= 1; y++)
        for (int x = -1; x <= 1; x++)
            cost = max(cost, src0.Load(int3(clamp(hp + int2(x, y), int2(0, 0), mxx), 0)).z);
    dst[p] = smoothstep(c1.x, c1.y, cost / 25.0);
#else
    // Bilinear between the 1/2-resolution vectors (manual: this pass has no sampler bound).
    float2 q = (float2(p) + 0.5) * 0.5 - 0.5;
    int2 b = int2(floor(q));
    float2 f = q - float2(b);
    int2 mx = Size(src0) - 1;
    float2 v00 = src0.Load(int3(clamp(b, int2(0, 0), mx), 0)).xy;
    float2 v10 = src0.Load(int3(clamp(b + int2(1, 0), int2(0, 0), mx), 0)).xy;
    float2 v01 = src0.Load(int3(clamp(b + int2(0, 1), int2(0, 0), mx), 0)).xy;
    float2 v11 = src0.Load(int3(clamp(b + int2(1, 1), int2(0, 0), mx), 0)).xy;
    float2 v = lerp(lerp(v00, v10, f.x), lerp(v01, v11, f.x), f.y) * 2.0;
    dst[p] = float4(v * c1.x, 0.0, 0.0);
#endif
}
