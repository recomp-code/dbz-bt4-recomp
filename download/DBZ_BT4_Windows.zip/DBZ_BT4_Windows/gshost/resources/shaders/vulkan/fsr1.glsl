#version 460 core

// AMD FidelityFX Super Resolution 1.0 (EASU upscale + RCAS sharpen) for the PS2Recomp live
// renderer. Based on the FSR 1 samples. Copyright (c) 2021 Advanced Micro Devices, Inc.
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

layout(push_constant) uniform const_buffer
{
    uvec4 const0;
    uvec4 const1;
    uvec4 const2;
    uvec4 const3;
};

layout(set=0, binding=0) uniform sampler2D imgSrc;
layout(set=0, binding=1, rgba8) uniform writeonly image2D imgDst;
// 0 = EASU (upscale, const0..3 from FsrEasuConOffset), 1 = RCAS (sharpen, const0 from FsrRcasCon).
layout(constant_id=0) const int fsrPass = 0;

#define A_GPU 1
#define A_GLSL 1
#include "ffx_a_fsr.h"

#define FSR_EASU_F 1
AF4 FsrEasuRF(AF2 p) { return textureGather(imgSrc, p, 0); }
AF4 FsrEasuGF(AF2 p) { return textureGather(imgSrc, p, 1); }
AF4 FsrEasuBF(AF2 p) { return textureGather(imgSrc, p, 2); }

#define FSR_RCAS_F 1
AF4 FsrRcasLoadF(ASU2 p) { return texelFetch(imgSrc, p, 0); }
void FsrRcasInputF(inout AF1 r, inout AF1 g, inout AF1 b) {}

#include "ffx_fsr1.h"

void FilterPixel(AU2 pos)
{
    AF3 c;
    if (fsrPass == 0)
        FsrEasuF(c, pos, const0, const1, const2, const3);
    else
        FsrRcasF(c.r, c.g, c.b, pos, const0);
    imageStore(imgDst, ASU2(pos), AF4(c, 1.0));
}

layout(local_size_x=64) in;
void main()
{
    // Same 16x16 tile per workgroup (4 pixels per thread) as the FSR samples.
    AU2 gxy = ARmp8x8(gl_LocalInvocationID.x) + AU2(gl_WorkGroupID.x << 4u, gl_WorkGroupID.y << 4u);
    FilterPixel(gxy);
    gxy.x += 8u;
    FilterPixel(gxy);
    gxy.y += 8u;
    FilterPixel(gxy);
    gxy.x -= 8u;
    FilterPixel(gxy);
}
